$(document).ready(function(){
    $('.anim-1').waypoint(function(){
        $('.anim-1').addClass('animate__animated animate__fadeInLeft')
    },{
        offset : '45%'
    })
    $('.anim-2').waypoint(function(){
        $('.anim-2').addClass('animate__animated animate__fadeInRight')
    },{
        offset : '45%'
    })
    $('.anim-3').waypoint(function(){
        $('.anim-3').addClass('animate__animated animate__fadeInUp')
    },{
        offset : '45%'
    })
    $('.anim-4').waypoint(function(){
        $('.anim-4').addClass('animate__animated animate__fadeInUp')
    },{
        offset : '45%'
    })
    $('.anim-5').waypoint(function(){
        $('.anim-5').addClass('animate__animated animate__fadeInUp')
    },{
        offset : '45%'
    })
    $('.anim-client').waypoint(function(){
        $('.anim-client').addClass('animate__animated animate__fadeInUp')
    },{
        offset : '45%'
    })
    $('footer').waypoint(function(){
        $('footer').addClass('animate__animated animate__slideInUp')
    },{
        offset : '45%'
    })
    $('.anim-6').waypoint(function(){
        $('.anim-6').addClass('animate__animated animate__lightSpeedInLeft')
    },{
        offset : '45%'
    })
    $('.anim-7').waypoint(function(){
        $('.anim-7').addClass('animate__animated animate__fadeInLeft')
    },{
        offset : '45%'
    })
    $('.anim-8').waypoint(function(){
        $('.anim-8').addClass('animate__animated animate__fadeInRight')
    },{
        offset : '45%'
    })
})